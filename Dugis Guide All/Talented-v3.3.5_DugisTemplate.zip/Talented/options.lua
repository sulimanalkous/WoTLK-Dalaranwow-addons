local L = LibStub("AceLocale-3.0"):GetLocale("Talented")
local Talented = Talented

Talented.max_talent_points = 71

Talented.defaults = {
	profile = {

-- Always Edit the template, never lock
		always_edit = true,

-- Manually confirm each talent before learning
		confirmlearn = true,

-- Call LearnTalent() even if Talented has determined that it would not have any effect
		-- always_call_learn_talents = nil,

-- Limit Talented to the level cap
		level_cap = true,

-- Show the required level for any template
		show_level_req = true,

-- Offset between Talent icons
		offset = 54,

-- Global frame scale
		scale = 0.9,

-- the template that was selected last
	--	last_template = nil,

		framepos = {},

-- Do we hook the inspect UI to replace it by Talented ?
		-- hook_inspect_ui = nil,

-- Use a dialog to output URL or show them directly in Chat ?
		-- show_url_in_chat = nil,

-- Glyph frame handling of Talent Swap
		glyph_on_talent_swap = "keep",
	},
	global = {
	-- the list of saved templates, see below for the format
			templates = {
			["Protection Leveling (80)"] = "Mr200DZmAZ5p1CN31FAp1doa",
			["Fury Leveling (40)"] = "MZmtPa05n0ta",
			["Affliction (31)"] = "pD0CCnc0a",
			[".PVP Frost Best for Arena"] = "aD0DD023ZZrpApaAn0DB2Dau",
			[".PVP Retribution"] = "d50AZ5o1Z5DBtCpnoBpAd1",
			["Retribution Leveling (37)"] = "dZZ5BCuAanm",
			["Elemental Leveling (46)"] = "m5p0fDB1umA",
			["Arms Leveling (68)"] = "M5C2BDp10AAcBobFamt",
			["Balance Leveling (43)"] = "0toD1F3a31ZZ3",
			["Protection Leveling (60)"] = "MZZ5p1CN31FAp1doa",
			[".PVP Full Feral"] = "0Zto2d3ABAwcmpnrb0y01",
			["Arcane Leveling (80)"] = "a0t5D0A31tonouwBD503a",
			["Subtlety Dagger Level (71)"] = "DctAaZZtA3Bpo1Br150cu",
			["Arcane Leveling (43)"] = "a2t5D0031Mon",
			[".PVE Fire (DPS)"] = "aD053b0DZ0y30cmpm5nAm3u",
			["Destruction Leveling (71)"] = "pZ3Z5D2fC3n5dr3du",
			[".PVP Marksmanship"] = "3ZAw5DamBmpdtn5aD0pAaA",
			["Survival & Marksmanship DPS (16)"] = "tB00d300mab",
			["Protection Leveling (63)"] = "MZmZ5p1CN31FAp1doa",
			["Balance Leveling (63)"] = "0toDnF3a3B0rbanZ3",
			["Enhancement Leveling (80)"] = "m5mqaZ0ttpat1pondcn5a",
			["Protection Leveling (70)"] = "M52ZmZ5p1CN31FAp1doa",
			["Fire Leveling (30)"] = "aZD50Ccm01",
			[".PVP Arcane"] = "aD0FD123B3o1ou3BD50Dam",
			["Balance Leveling (23)"] = "0tcA1ZZ3",
			["Survival Leveling (50)"] = "3ZZw0mFa1pmtnA0a",
			["Beast Mastery Leveling (60)"] = "3tAmBttb5nawbu",
			["Paladin Protection (40)"] = "dZ50ur21tma",
			["Elemental Leveling (71)"] = "m5p0fDB1uoD1Fa0tt0a",
			["Marksmanship Leveling (50)"] = "3Z0w5Dc01opbO",
			["Shadow Leveling (75)"] = "A5ZZotDFcDbADfDbra",
			[".PVP Arms Best for Arena"] = "M3ApADpu0ACc1onFaot0d",
			["Discipline Leveling (53)"] = "A53AnmmFcpa30aZZm",
			["Beast Mastery Leveling (40)"] = "3tAmBttb51",
			["Marksmanship Leveling (74)"] = "3tAZ0w5Dc01opdvm3at00A",
			["Frost Leveling (69)"] = "aZZrp0pdAn0DBvDdu",
			[".PVE Unholy (DPS)"] = "PD522ZZD20pt3Bv0nt0npfa",
			["Holy Leveling (68)"] = "dFr1t20dF10ttAZ5D00A",
			[".PVE Discipline (Healing)"] = "A53Ammo5cmdDDcuAtu3",
			[".PVE Arcane (DPS)"] = "aDA5D10p1ton2twB3ZAo30a",
			["Subtlety Dagger Level (80)"] = "DotAatZZtA3Bpo1Br15Acu",
			[".PVE DW Frost Tanking"] = "P0yZmtw0r0pa30Dnnra0t",
			["Enhancement Leveling (46)"] = "mZ0ttpat1pmba2",
			["Demonology (50)"] = "pZ0o3mbrbFadt1",
			[".PVE Restoration (Healing)"] = "mZ0ttmZt0wnptdtbCpcu",
			["Frost Leveling (80) DK"] = "PZo1ttrA3bD10n1raD2m0tD",
			["Fire Leveling (66)"] = "aZD53Dcm0nFn20dumm",
			[".PVE Protection (Tanking)"] = "M5ZmtZ5puCv0BFBp1doa",
			["Assassination Leveling (17)"] = "D2m3",
			[".PVP Enhancement"] = "m53raZ2mv3at1pobdcnFa",
			["Assassination Leveling (20)"] = "D2t3a",
			[".PVP Elemental"] = "m5p0fDB1uoDnra0tv3a",
			[".PVP Fire"] = "aD0DD023ZD53Ccm0nFn0mdu",
			["Beast Mastery Leveling (50)"] = "3tAmBttb5nata",
			["Frost Leveling (67) DK"] = "PZo0ttrA3bD10n1ZD2m0tA",
			["Holy Leveling (31)"] = "d5r0t21",
			["Fire Leveling (40)"] = "aZD53Dcm0nA1",
			["Survival Leveling (40)"] = "3ZZD0mFa1pmM1",
			["Retribution Leveling (20)"] = "dZZ5BA1",
			["Beast Mastery Tanking (20)"] = "*0o0Co1Ab1",
			["Arms Leveling (47)"] = "M5C2BDp10AAcB2",
			["Protection Leveling (51)"] = "MZZ5p1CN31FAp1a",
			["Frost Leveling (60)"] = "aZZrp0pdAn0DB2Ddb",
			["Retribution Leveling (63)"] = "dZZ5DCuApnmBpAdn",
			["Unholy Leveling (67)"] = "PAZZD2mpuDB00ntBn3fa",
			["Subtlety Dagger Level (32)"] = "D2ZZtA3bmo11",
			["Survival Leveling (30)"] = "3ZZD0mFa1n",
			["Enhancement Leveling (75)"] = "m5AmaZ0ttpat1pondcn5a",
			["Fury Leveling (70)"] = "M5C1ZmtPa05nAtc5bra",
			[".PVP Destruction"] = "pZ0oAmbmAZ5D0fC3nrd53au",
			[".PVP Beast Mastery"] = "3tD21tvb5n2wau0w5aaZ3",
			["Shadow Leveling (68)"] = "A5ZZotDAcDbADf3bra",
			["Arms Leveling (30)"] = "M5C1BC31",
			["Frost Leveling (20)"] = "aZZrA00a",
			["Frost Leveling (80)"] = "aZZrpDpdDnmDBvDdu",
			["Paladin Protection (50)"] = "dZ50ur21toco1",
			["Survival & Marksmanship PVP (16)"] = "wB0103m0Caa",
			["Marksmanship Leveling (30)"] = "3Z0v5Acm1",
			["Retribution Leveling (80)"] = "dZ5ZyDCuCpnoBpDdn",
			[".PVP Fury"] = "Mo0D0DmZmtmd05nBtcFbra",
			["Balance Leveling (73)"] = "0toDnF3apBmrncnZ3",
			["Arms Leveling (27)"] = "M5C1BA3",
			["Destruction Leveling (80)"] = "pZ31Z5DofCpn5drDdu",
			[".PVP Assasination Best Arena Spec"] = "Dmt3aw2aFCao1Z0tZwADA0mBA",
			["Retribution Leveling (68)"] = "dZ5Z5DCuApnmBpAdn",
			["Fire Leveling (60)"] = "aZD53Dcm0nFn20du",
			["Combat Sword Leveling (40)"] = "DZ2Or100tf21",
			["Unholy Leveling (62)"] = "PAZZD2mpuDB00ntBn3aa",
			["Balance Leveling (54)"] = "0toDBF3a3B0o1aZZ3",
			["Fire Leveling (72)"] = "aZD53DcmpnFn20dumm",
			["Arms Leveling (42)"] = "M5C2BDp10AAaA",
			["Feral Leveling (80)"] = "0Zyo2d3CA0wc3mnra0y01",
			["Fire Leveling (75)"] = "aZD53DcmpnFn20dump",
			["Unholy Leveling (72)"] = "PAZmZD2mpuDB20ntBn3fa",
			["Shadow Leveling (37)"] = "AZZmtCAbDbA3",
			["Elemental Leveling (80)"] = "m5p0fDB1uoD1ra0tvpa",
			["Frost Leveling (53)"] = "aZZrp0pdAn03B2Da",
			["Marksmanship Leveling (67)"] = "3Z0w5Dc01opdvm3at00A",
			["Subtlety Dagger Level (11)"] = "D2",
			[".PVE Enhancement (DPS)"] = "m5mqaZ0ttpat1pondcn5a",
			["Marksmanship Leveling (40)"] = "3Z0w5Dc01oma",
			["Combat Sword Leveling (20)"] = "DZ2om1",
			["Arcane Leveling (60)"] = "a0t5D0A31ton2utB",
			[".PVP Unholy Best for Arena"] = "PZ0vt1A2ZD2op00BvDn1An3fa",
			["Beast Mastery PVP (20)"] = "wB0103m0CbbA",
			["Demonology (40)"] = "pZ0o3mbrbF0a",
			[".PVE Arms DPS"] = "MmC3ADpu0aAcBonFamtZAp",
			[".PVP Balance with Spirit Gear"] = "0yoD1A3aDBmr1cnZD0pnA",
			["Survival Leveling (20)"] = "3ZZD0mAa",
			["Feral Leveling (61)"] = "0Zto2d3CA0wc1m1Z0y01",
			[".PVE Shadow (DPS)"] = "A53AmZZotD5cD13DfD1ra",
			[".PVP Holy Defensive Arena 3vs3 5vs5"] = "dtnBtm2d5n3NOBto1nC",
			["Shadow Leveling (30)"] = "AZZmtCAaD1",
			[".PVE Priest Holy (Healing)"] = "A53AnZ3tu3C0fFm2wn5a",
			["Survival Leveling (80)"] = "3tZ0w5Zw0mFaDpmwnm0d1",
			["Frost Leveling (72)"] = "aZZrp0pdAnmDBvDdu",
			["Elemental Leveling (40)"] = "m5p0fDB0u",
			["Discipline Leveling (80)"] = "A53AnmmFcpa3AcuCtu00AZm",
			[".PVE Druid Restoration (Healing)"] = "05o0nZZD0pnAntFnFmd5a",
			["Fury Leveling (50)"] = "MZmtPa05nAtc51",
			["Fury Leveling (30)"] = "MZmtpa051",
			["Arcane Leveling (27)"] = "a0t5D003",
			[".PVE Elemental (DPS)"] = "mrm0fDBpuoD1ra0tt3a",
			["Affliction (21)"] = "pD0BA1",
			["Demonology (71)"] = "pZ0o3mbrbFAdt1ray00a",
			[".PVE Retribution (DPS)"] = "dZy014AZ5DAtApnmBpDdn",
			["Fury Leveling (80)"] = "M5231DmZmtwa05nAtc5bra",
			["Frost Leveling (64)"] = "aZZrp0pdAn0DB2Ddu",
			["Beast Mastery Leveling (72)"] = "3tAmBttb5nawbu0t5A",
			[".PVP Full Protection Great for PVP and Tanking"] = "M5230DZmZ50uCv31FBp1doa",
			["Assassination Leveling (40)"] = "D2t3auva50a",
			["Arcane Leveling (50)"] = "a0t5D0A31ton0u",
			[".PVP Holy 'Shockadin'"] = "dFr1t20dF10utAZ5D2tA31",
			["Arms Leveling (20)"] = "M5C11",
			["Assassination Leveling (50)"] = "D2t3awva5Aao1",
			["Retribution Leveling (22)"] = "dZZ5BA1A",
			["Shadow Leveling (26)"] = "AZZmtCAaA",
			[".PVP Survival"] = "3Z0w50aZD0pFaDpmwBm2dn",
			["Destruction Leveling (66)"] = "pZ3Z5D2fC3n5do1du",
			["Balance Leveling (33)"] = "0toD1C0aZZ3",
			["Survival Leveling (60)"] = "3ZZw0mFa3pmwnm0d1",
			["Shadow Leveling (12)"] = "AZZm",
			["Subtlety Dagger Level (52)"] = "D2ZZtA3bpo1Bq150a",
			[".PVE Demonology (DPS)"] = "p3ZAo0mbrBFAdv1ray005",
			["Demonology (80)"] = "pZ0o3mbrBFmdt1ray00fA",
			["Elemental Leveling (30)"] = "m5p0fB1",
			[".PVE Feral (Tanking)"] = "0ZtCodDC13wc301rbAr30A",
			[".PVP Affliction Best for Arena"] = "p1t2CnCrbf523bu0oAmbmA",
			[".PVP Balance for Crit Rating Gear"] = "0toDnF3aDB0r1cnZD0pnA",
			["Shadow Leveling (80)"] = "A50AZZotDFcDbDDfDbra",
			["Assassination Leveling (69)"] = "Dot3awva5Aap15a0vZ0A",
			["Beast Mastery Leveling (30)"] = "3tAmBAta",
			["Retribution Leveling (43)"] = "dZZ5BCuAmnm1m",
			[".PVP Shadow"] = "AtD0nZZ0vDFcDbADfDbFa",
			[".PVP Subtlety Arena / BG"] = "Dmw0aZ0tZwAAAmoBB51r3cu",
			["Balance Leveling (12)"] = "0ZZ3",
			[".PVP Combat with Hemorrhage"] = "DZmtrB0D0f0nAvcZw0DAmm1B",
			["Protection Leveling (30)"] = "MZZ5p1CM01",
			["Assassination Leveling (74)"] = "Dot3awva5Aap15a0v5Z0A",
			["Retribution Leveling (33)"] = "dZZ5BCuA0n",
			[".PVP Restoration"] = "mZ0vvmaZ53DndAdvbApcu",
			["Demonology (60)"] = "pZ0o3mbrbFAdt1ra",
			["Destruction Leveling (42)"] = "pZZ5D0fC1n5am",
			[".PVP 'Restokin' Good For BG / 2vs2"] = "0yoD1A3aDBmm1cZZD0pnAnt",
			["Shadow Leveling (78)"] = "A5ZZotDFcDbDDfDbra",
			[".PVE Combat (DPS)"] = "DmtA0wZ2v5at3taCn0tcuA",
			["Fury Leveling (78)"] = "M5C10DmZmtPa05nAtc5bra",
			["Elemental Leveling (60)"] = "m5p0fDB1uoD1Fa",
			["Combat Sword Leveling (50)"] = "DZ2vr100tf2n0ta",
			["Discipline Leveling (20)"] = "A53ZZm",
			["Discipline Leveling (45)"] = "A53AnmmCcpZZm",
			["Protection Leveling (41)"] = "MZZ5p1CN11FA",
			["Balance Leveling (26)"] = "0tcD1ZZ3",
			["Fire Leveling (20)"] = "aZD500a",
			["Frost Leveling (50)"] = "aZZrp0pdAn03B2Aa",
			["Affliction (61)"] = "pD0CAnCdb5radbu01",
			[".PVE Balance (DPS)"] = "0toAnF3dpBm5n0nZAt3nA",
			["Shadow Leveling (60)"] = "AZZmtCAcDbADf3bra",
			["Shadow Leveling (63)"] = "AZZotDAcDbADf3bra",
			[".PVE Survival (DPS)"] = "3Z0w5aaZt03F03pmwBrmdB",
			["Blood Leveling (77)"] = "PD0ofm3pdAaDaduZD2m0tA",
			["Arms Leveling (60)"] = "M5C2BDp10AAcBobFa",
			["Destruction Leveling (26)"] = "pZZ5D0e2",
			["Destruction Leveling (30)"] = "pZZ5D0fC01",
			["Retribution Leveling (30)"] = "dZZ5BCuA01",
			["Shadow Leveling (50)"] = "AZZmtCAcDbADf31",
			["Retribution Leveling (60)"] = "dZZ5BCuApnmBoAdn",
			["Arcane Leveling (74)"] = "a0t5D0A31ton2utBD503a",
			["Fire Leveling (63)"] = "aZD53Dcm0nFn20dum",
			["Survival Leveling (70)"] = "3Z0t5Zw0mFa3pmwnm0d1",
			["Survival & Marksmanship Tanking (16)"] = "*0o0CC1a1",
			["Combat Sword Leveling (73)"] = "Dmv0aZ2vr100tfCn0vcu",
			["Enhancement Leveling (40)"] = "mZo0tpat1nmb",
			[".PVE Feral (DPS) "] = "0Zy203DC1Awc0mnrb0y31A",
			["Arms Leveling (80)"] = "M5C2BDpu0ACcBonFaot0a",
			[".PVE Assassination  (DPS)"] = "D0wD0wta5Aapn5a0t50mZtA",
			["Discipline Leveling (12)"] = "AZZm",
			["Holy Leveling (40)"] = "d5r1t20d51",
			["Destruction Leveling (48)"] = "pZZ5D0fC1n5dm",
			["Destruction Leveling (20)"] = "pZZ5D0a",
			["Unholy Leveling (60)"] = "PZZD2mpuDB00ntBn3aa",
			["Combat Sword Leveling (71)"] = "Dmv0aZ2vr100tf2n0vcu",
			["Assassination Leveling (80)"] = "Dow3awva5Aapn5a0v5Z0A",
			["Destruction Leveling (60)"] = "pZZ5D0fC2n5do1du",
			["Fire Leveling (53)"] = "aZD53Dcm0nFn0ad",
			["Enhancement Leveling (64)"] = "mZ0ttpat1pondcn5a",
			["Assassination Leveling (11)"] = "D2",
			["Subtlety Dagger Level (39)"] = "D2ZZtA3bpo11m",
			["Enhancement Leveling (50)"] = "mZ0ttpat1pmbcc1",
			["Balance Leveling (80)"] = "0xoDnFpapBmrncnZ3",
			["Paladin Protection (71)"] = "dZ50ur21vmdpnAB5D01",
			["Frost Leveling (40)"] = "aZZrp0pdAn001",
			["Feral Leveling (31)"] = "0Zto2d3A",
			["Retribution Leveling (50)"] = "dZZ5BCuApnmBmaa",
			["Fury Leveling (60)"] = "MZmtPa05nAtc5bra",
			[".PVP Frost 2H"] = "PD5oZ2vt1rC3aD1An1ra3",
			["Fire Leveling (80)"] = "aZD53DcmpnFn2mdump10a",
			["Discipline Leveling (74)"] = "A53AnmmFcpa3Acu0tuZm",
			[".PVP Discipline Best for Arena"] = "AtD2npo5cDaDDcuAmu",
			["Arcane Leveling (30)"] = "a2t5D0031",
			["Assassination Leveling (60)"] = "Dot3awva5Aap15a",
			["Destruction Leveling (64)"] = "pZ3Z5D0fC3n5do1du",
			["Enhancement Leveling (30)"] = "mZo0tnat1",
			["Blood Leveling (67)"] = "PD0ofm3pdAaD0aZZD2m0tA",
			["Frost Leveling (30)"] = "aZZrD03a0n",
			["Affliction (52)"] = "pD0CAnCDb5ra0bZ01",
			["Frost Leveling (77) DK"] = "PZo1ttrA3bD10n1raD2m0tA",
			[".PVE Holy (Healing)"] = "dtr1tm0d5n0uvBtZ5BAt",
			["Holy Leveling (77)"] = "dFr1t20dF10ttAZ5D0tA31",
			["Demonology (30)"] = "pZ0o2mbr1",
			["Paladin Protection (60)"] = "dZ50ur21todpnAB",
			[".PVP Restoration Defensive Build"] = "05o01AZZD0pnAntFbrmdFa",
			["Feral Leveling (20)"] = "0Zto0a",
			["Fury Leveling (22)"] = "MZmtD",
			["Marksmanship Leveling (20)"] = "3Z0t50a",
			["Affliction (80)"] = "pD0CAnCrb5rapbuAo0mam",
			["Subtlety Dagger Level (22)"] = "D2ZZtA31",
			["Blood Leveling (80)"] = "PD0ofm3pdAaDaduZD2m0tD",
			["Balance Leveling (76)"] = "0toDnFpapBmrncnZ3",
			[".PVP Demonology"] = "pZ0oDmbrA5pdt1ra5D0f",
			["Beast Mastery Leveling (20)"] = "3tAm1",
			["Shadow Leveling (40)"] = "AZZmtCAbDbADa",
			["Subtlety Dagger Level (42)"] = "D2ZZtA3bpo1Bm1",
			["Assassination Leveling (32)"] = "D2t3aMva",
			["Destruction Leveling (50)"] = "pZZ5D0fC2n5do0a",
			["Combat Sword Leveling (60)"] = "DZ2vr100tf2n0vcu",
			[".PVP Arms/Prot Hybrid"] = "M3C3BDpu0ACa12BAZmZ50uCN01A",
			["Discipline Leveling (33)"] = "A53Anmm0aZZm",
			["Discipline Leveling (39)"] = "A53AnmmCcZZm",
			["Holy Leveling (26)"] = "d550t2",
			["Unholy Leveling (80)"] = "PAZmZD2mpuDBv0ntBnpfa",
			[".PVP Holy Offensive Good for 2vs2"] = "dtmBtmCd5n3aZZ5D2tCm1o1",
			["Blood Leveling (57)"] = "PD0ofm3pd0aZZD2m0tAa",
			["Elemental Leveling (50)"] = "m5p0fDB1uoB1",
			["Elemental Leveling (20)"] = "m5o0a",
			["Protection Leveling (21)"] = "MZZ4p0A",
			["Holy Leveling (80)"] = "dFr1t20dF10utAZ5D2tA31",
			["Demonology (20)"] = "pZ0o2ma",
			["Beast Mastery Leveling (80)"] = "3tAm1tvbFn2wdu0w5A",
			["Assassination Leveling (62)"] = "Dot3awva5Aap15aZ0A",
			["Paladin Protection (30)"] = "dZ50tr21",
			["Paladin Protection (80)"] = "dZ50ur21todpnAB5D0NA3",
			["Subtlety Dagger Level (62)"] = "D2ZZtA3Bpo1Br150cu",
			["Destruction Leveling (40)"] = "pZZ5D0fC1n5a",
			["Combat Sword Leveling (80)"] = "DmtAatZ2vrB00tfCn0vcu",
			["Enhancement Leveling (20)"] = "mZo0t0a",
			["Shadow Leveling (20)"] = "AZZmtA0a",
			["Balance Leveling (19)"] = "0t0AZZ3",
			["Arms Leveling (50)"] = "M5C2BDp10AAcBC1",
			["Beast Mastery DPS (20)"] = "tB00D301maca",
			[".PVE Fury (DPS)"] = "Mq030DmZmtw050n2wc51ra",
			["Marksmanship Leveling (60)"] = "3Z0w5Dc01opdvm3a",
			["Affliction (44)"] = "pD0CCnCAb5ma",
			["Combat Sword Leveling (30)"] = "DZ2oq100ta",
			["Affliction (67)"] = "pD0CAnCrb5rapbu01",
			["Frost Leveling (60) DK"] = "PZo0ttrA3b31ZD2m0tA",
			["Balance Leveling (68)"] = "0toDnF3a3BmrnanZ3",
			[".PVE Paladin Protection (Tanking)"] = "dZ50urcn2odpnDByd00A",
			["Discipline Leveling (63)"] = "A53AnmmFcpa3AcuZm",
			["Holy Leveling (56)"] = "dFr1t20dF10ttA",
			["Feral Leveling (50)"] = "0Zto2d3CA0wc1m1",
			["Marksmanship Leveling (80)"] = "3tAZ0w5Dcm1opdvn5at00A",
			["Fire Leveling (77)"] = "aZD53DcmpnFn20dump10a",
			["Feral Leveling (40)"] = "0Zto2d3CA0ta",
			[".PVE Destruction (DPS)"] = "p3ZD20m0mZ5Ao5C3n5ar3du",
			[".PVE Affliction (DPS)"] = "pDt2A12ra5r0pbu01Zy025",
			[".PVP Restoration Offensive Build"] = "0yoA1A0aZZD0pnAntE1r0dD",
			},
	},
	char = {
		targets = {},
	},
}

function Talented:SetOption(info, value)
	local name = info[#info]
	self.db.profile[name] = value
	local arg = info.arg
	if arg then self[arg](self) end
end

function Talented:GetOption(info)
	local name = info[#info]
	return self.db.profile[name]
end

function Talented:MustNotConfirmLearn()
	return not Talented.db.profile.confirmlearn
end

Talented.options = {
	desc = L["Talented - Talent Editor"],
	type = "group",
	childGroups = "tab",
	handler = Talented,
	get = "GetOption",
	set = "SetOption",
	args = {
		options = {
			name = L["Options"],
			desc = L["General Options for Talented."],
			type = "group",
			args = {
				header1 = {
					name = L["General options"],
					type = "header",
					order = 1,
				},
				always_edit = {
					name = L["Always edit"],
					desc = L["Always allow templates and the current build to be modified, instead of having to Unlock them first."],
					type = "toggle",
					arg = "UpdateView",
					order = 100,
				},
				confirmlearn = {
					name = L["Confirm Learning"],
					desc = L["Ask for user confirmation before learning any talent."],
					type = "toggle",
					order = 200,
				},
				always_call_learn_talents = {
					name = L["Always try to learn talent"],
					desc = L["Always call the underlying API when a user input is made, even when no talent should be learned from it."],
					type = "toggle",
					disabled = "MustNotConfirmLearn",
					order = 220,
				},
				level_cap = {
					name = L["Talent cap"],
					desc = L["Restrict templates to a maximum of %d points."]:format(Talented.max_talent_points),
					type = "toggle",
					arg = "UpdateView",
					order = 300,
				},
				show_level_req = {
					name = L["Level restriction"],
					desc = L["Show the required level for the template, instead of the number of points."],
					type = "toggle",
					arg = "UpdateView",
					order = 400,
				},
				hook_inspect_ui = {
					name = L["Hook Inspect UI"],
					desc = L["Hook the Talent Inspection UI."],
					type = "toggle",
					arg = "CheckHookInspectUI",
					order = 700,
				},
				show_url_in_chat = {
					name = L["Output URL in Chat"],
					desc = L["Directly outputs the URL in Chat instead of using a Dialog."],
					type = "toggle",
					order = 750,
				},
				header2 = {
					name = L["Glyph frame options"],
					type = "header",
					order = 769,
				},
				glyph_on_talent_swap = {
					name = L["Glyph frame policy on spec swap"],
					desc = L["Select the way the glyph frame handle spec swaps."],
					type = "select",
					order = 770,
					width = "double",
					values = {
						keep = L["Keep the shown spec"],
						swap = L["Swap the shown spec"],
						active = L["Always show the active spec after a change"],
					},
				},
				header3 = {
					name = L["Display options"],
					type = "header",
					order = 799,
				},
				offset = {
					name = L["Icon offset"],
					desc = L["Distance between icons."],
					type = "range",
					min = 42,
					max = 64,
					step = 1,
					order = 800,
					arg = "ReLayout",
				},
				scale = {
					name = L["Frame scale"],
					desc = L["Overall scale of the Talented frame."],
					type = "range",
					min = 0.5,
					max = 1.0,
					step = 0.01,
					order = 900,
					arg = "ReLayout",
				},
				add_bottom_offset = {
					name = L["Add bottom offset"],
					desc = L["Add some space below the talents to show the bottom information."],
					type = "toggle",
					order = 950,
					arg = "ReLayout",
				},
			}
		},
		apply = {
			name = "Apply",
			desc = "Apply the specified template",
			type = "input",
			dialogHidden = true,
			set = function (_, name)
				local template = Talented.db.global.templates[name]
				if not template then
					Talented:Print(L["Can not apply, unknown template \"%s\""], name)
					return
				end
				Talented:SetTemplate(template)
				Talented:SetMode"apply"
			end,
		},
	},
}

function Talented:ReLayout()
	self:ViewsReLayout(true)
end

function Talented:UpgradeOptions()
	local p = self.db.profile
	if p.point or p.offsetx or p.offsety then
		local opts = {
			anchor = p.point or "CENTER",
			anchorTo = p.point or "CENTER",
			x = p.offsetx or 0,
			y = p.offsety or 0,
		}
		p.framepos.TalentedFrame = opts
		p.point, p.offsetx, p.offsety = nil, nil, nil
	end
	local c = self.db.char
	if c.target then
		c.targets[1] = c.target
		c.target = nil
	end
	self.UpgradeOptions = nil
end

function Talented:SaveFramePosition(frame)
	local db = self.db.profile.framepos
	local name = frame:GetName()

	local data, _ = db[name]
	if not data then
		data = {}
		db[name] = data
	end
	data.anchor, _, data.anchorTo, data.x, data.y = frame:GetPoint(1)
end

function Talented:LoadFramePosition(frame)
	local data = self.db.profile.framepos[frame:GetName()]
	if data and data.anchor then
		frame:ClearAllPoints()
		frame:SetPoint(data.anchor, UIParent, data.anchorTo, data.x, data.y)
	else
		frame:SetPoint"CENTER"
		self:SaveFramePosition(frame)
	end
end

local function BaseFrame_OnMouseDown(self)
	if self.OnMouseDown then self:OnMouseDown() end
	self:StartMoving()
end

local function BaseFrame_OnMouseUp(self)
	self:StopMovingOrSizing()
	Talented:SaveFramePosition(self)
	if self.OnMouseUp then self:OnMouseUp() end
end

function Talented:SetFrameLock(frame, locked)
	local db = self.db.profile.framepos
	local name = frame:GetName()
	local data = db[name]
	if not data then
		data = {}
		db[name] = data
	end
	if locked == nil then
		locked = data.locked
	elseif locked == false then
		locked = nil
	end
	data.locked = locked
	if locked then
		frame:SetMovable(false)
		frame:SetScript("OnMouseDown", nil)
		frame:SetScript("OnMouseUp", nil)
	else
		frame:SetMovable(true)
		frame:SetScript("OnMouseDown", BaseFrame_OnMouseDown)
		frame:SetScript("OnMouseUp", BaseFrame_OnMouseUp)
	end
	frame:SetClampedToScreen(true)
end

function Talented:GetFrameLock(frame)
	local data = self.db.profile.framepos[frame:GetName()]
	return data and data.locked
end
