-- Speed
-- format("%d%%",(GetUnitSpeed("vehicle") / 7) * 100);

-- Character Health & Mana
--	PlayerFrameHealthBar.showNumeric = nil;
--	PlayerFrameManaBar.showNumeric = nil;
--	PlayerFrameAlternateManaBar.showNumeric = nil;
--	HideTextStatusBarText(PlayerFrameHealthBar);
--	HideTextStatusBarText(PlayerFrameManaBar);
--	HideTextStatusBarText(PlayerFrameAlternateManaBar);

-- Player Frame
-- PlayerFrame:Show();

local PointX = -2;

local hpHandlerFrame = CreateFrame("FRAME", "hpHandlerFrame");
hpHandlerFrame:RegisterEvent("UNIT_HEALTH");
local function hpHandler(self, event)
  local PlayerHealth = format("%d%%", (UnitHealth("player") / UnitHealthMax("player")) * 100);
  HealthFrame:SetText(PlayerHealth);
  local stringwidth = HealthFrame:GetStringWidth(PlayerHealth);
  HealthFrame:SetPoint("LEFT", PlayerFrame, "RIGHT", PointX, HealthFrame.PointYos);
end
hpHandlerFrame:SetScript("OnEvent", hpHandler);

local powerHandlerFrame = CreateFrame("FRAME", "energyHandlerFrame");
powerHandlerFrame:RegisterEvent("UNIT_MANA");
powerHandlerFrame:RegisterEvent("UNIT_RAGE");
powerHandlerFrame:RegisterEvent("UNIT_FOCUS");
powerHandlerFrame:RegisterEvent("UNIT_ENERGY");
powerHandlerFrame:RegisterEvent("UNIT_RUNIC_POWER");
local function powerHandler(self, event)
  local PlayerMana = UnitMana("player");
  ManaFrame:SetText(PlayerMana);
  local stringwidth = ManaFrame:GetStringWidth(PlayerMana);
  ManaFrame:SetPoint("LEFT", PlayerFrame, "RIGHT", PointX, ManaFrame.PointYos);
end
powerHandlerFrame:SetScript("OnEvent", powerHandler);

local SpeedFrame = PlayerFrame:CreateFontString("SpeedFrame", "OVERLAY");
local HealthFrame = PlayerFrame:CreateFontString("HealthFrame", "OVERLAY");
local ManaFrame = PlayerFrame:CreateFontString("ManaFrame", "OVERLAY");





local deltaTime = 0;
local TPS = 1;
function SpeedFrame_OnUpdate(self, elapsed)
  deltaTime = deltaTime + elapsed;
  if (deltaTime >= TPS) then
    deltaTime = 0;

    local PlayerSpeed = format("%d%%",(GetUnitSpeed("player") / 7) * 100);
    SpeedFrame:SetText(PlayerSpeed);
    local stringwidth = SpeedFrame:GetStringWidth(PlayerSpeed);
    SpeedFrame:SetPoint("LEFT", PlayerFrame, "RIGHT", PointX, SpeedFrame.PointYos);
  end

  if (TPS >= 1) then
    TPS = .3;

    SpeedFrame:SetFontObject(PlayerFrameHealthBarText:GetFontObject());
    SpeedFrame:SetText(format("%.0f%%",(GetUnitSpeed("player") / 7) * 100));
    SpeedFrame:SetJustifyH("RIGHT");
    SpeedFrame:SetJustifyV("TOP");
    SpeedFrame.PointXos = PointX;
    SpeedFrame.PointYos = 20;
    stringwidth = SpeedFrame:GetStringWidth(SpeedFrame:GetText());
    SpeedFrame:SetPoint("LEFT", PlayerFrame, "RIGHT", SpeedFrame.PointXos, SpeedFrame.PointYos);

    HealthFrame:SetFontObject(PlayerFrameHealthBarText:GetFontObject());
    HealthFrame:SetText(format("%.0f%%", (UnitHealth("player") / UnitHealthMax("player")) * 100));
    HealthFrame:SetJustifyH("RIGHT");
    HealthFrame:SetJustifyV("TOP");
    HealthFrame.PointXos = PointX;
    HealthFrame.PointYos = 4;
    stringwidth = HealthFrame:GetStringWidth(HealthFrame:GetText());
    HealthFrame:SetPoint("LEFT", PlayerFrame, "RIGHT", HealthFrame.PointXos, HealthFrame.PointYos);

    ManaFrame:SetFontObject(PlayerFrameHealthBarText:GetFontObject());
    ManaFrame:SetText(UnitMana("player"));
    ManaFrame:SetJustifyH("RIGHT");
    ManaFrame:SetJustifyV("TOP");
    ManaFrame.PointXos = PointX;
    ManaFrame.PointYos = -7;
    stringwidth = ManaFrame:GetStringWidth(ManaFrame:GetText());
    ManaFrame:SetPoint("LEFT", PlayerFrame, "RIGHT", ManaFrame.PointXos, ManaFrame.PointYos);
  end
end
local spdFrame = CreateFrame("frame");
spdFrame:SetScript("OnUpdate", SpeedFrame_OnUpdate);
